# SkillBridge - Frontend + C++ CGI backend

This is a simple student-project website package. It uses HTML and CSS for the frontend and C++ for the project matching logic. No database is required for this demo.

## Files
- `index.html` - website and student form
- `style.css` - page styling
- `finder.cpp` - C++ backend; reads submitted form data and calculates project matches
- `compile.bat` - compiles the C++ backend with MinGW g++
- `README.md` - these instructions

## Important: GitHub Pages cannot run C++ backend code
GitHub Pages hosts static HTML/CSS/JavaScript only. The C++ program must run on a web server that supports CGI, such as Apache configured for CGI. Uploading `finder.cpp` to GitHub will not make it execute.

## Windows setup (one-time)
1. Install MinGW-w64 / MSYS2 and make sure `g++` works in the VS Code terminal (`g++ --version`).
2. Install XAMPP with Apache.
3. Copy `index.html` and `style.css` into `C:\xampp\htdocs\skillbridge\`.
4. Compile `finder.cpp` using `compile.bat` or this command in the folder:
   `g++ finder.cpp -o finder.exe`
5. Copy `finder.exe` into Apache's CGI folder, usually `C:\xampp\cgi-bin\`.
6. Ensure Apache CGI is enabled and the CGI folder is configured to execute `.exe` programs. On Windows, CGI configuration varies by Apache/XAMPP build; if Apache downloads the EXE or shows 500 error, CGI is not configured correctly.
7. Start Apache in XAMPP Control Panel.
8. Open `http://localhost/skillbridge/` and submit the form.

## Form endpoint
The form posts to `/cgi-bin/finder.exe`. If your Apache CGI folder uses a different URL, update the `action` attribute in `index.html`.

## Testing the C++ program
A C++ CGI program is not opened by double-clicking it. It is run by the web server when the form is submitted. A regular console run will not show a normal website response.

## Hosting online
GitHub Pages cannot execute this C++ backend. To use the C++ backend online, deploy it to a hosting provider/server that supports Apache CGI or another C++ web server. You can still use GitHub Pages for a frontend-only demo, but this package's form will need a live CGI server URL.
