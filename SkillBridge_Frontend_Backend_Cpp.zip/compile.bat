@echo off
echo Compiling SkillBridge C++ backend...
g++ -std=c++11 finder.cpp -o finder.exe
if errorlevel 1 (
  echo.
  echo Compilation failed. Check that MinGW-w64 is installed and g++ is in PATH.
  pause
  exit /b 1
)
echo.
echo Success! finder.exe has been created.
echo Copy finder.exe to your Apache CGI folder after configuring CGI.
pause
