#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <algorithm>
#include <map>
using namespace std;

string decode(string s) {
    string out;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '+') out += ' ';
        else if (s[i] == '%' && i + 2 < s.size()) {
            string hex = s.substr(i + 1, 2);
            char ch = (char)strtol(hex.c_str(), nullptr, 16);
            out += ch;
            i += 2;
        } else out += s[i];
    }
    return out;
}

map<string, vector<string>> readForm() {
    map<string, vector<string>> data;
    const char* lengthText = getenv("CONTENT_LENGTH");
    int length = lengthText ? atoi(lengthText) : 0;
    string body;
    for (int i = 0; i < length; ++i) {
        char ch = cin.get();
        if (!cin) break;
        body += ch;
    }
    stringstream ss(body);
    string item;
    while (getline(ss, item, '&')) {
        size_t pos = item.find('=');
        if (pos == string::npos) continue;
        string key = decode(item.substr(0, pos));
        string value = decode(item.substr(pos + 1));
        data[key].push_back(value);
    }
    return data;
}

string getValue(const map<string, vector<string>>& data, const string& key) {
    auto it = data.find(key);
    if (it == data.end() || it->second.empty()) return "";
    return it->second[0];
}

bool hasSkill(const vector<string>& skills, const string& skill) {
    return find(skills.begin(), skills.end(), skill) != skills.end();
}

struct Project {
    string name, category, description;
    vector<string> skills;
    string nextStep;
};

int main() {
    cout << "Content-Type: text/html; charset=UTF-8\r\n\r\n";
    map<string, vector<string>> form = readForm();
    string student = getValue(form, "name");
    string interest = getValue(form, "interest");
    vector<string> skills;
    auto skillIt = form.find("skills");
    if (skillIt != form.end()) skills = skillIt->second;

    vector<Project> projects = {
        {"Student Management System", "Software", "Store student details and manage basic academic records.", {"C++","HTML","CSS","SQL"}, "Practise SQL and learn how to store and search records."},
        {"Personal Portfolio Website", "Web Development", "A website to display your skills, projects and achievements.", {"HTML","CSS","JavaScript"}, "Practise JavaScript and make the website responsive."},
        {"College Event Website", "Web Development", "A website where students can view events and register.", {"HTML","CSS","JavaScript","SQL"}, "Learn JavaScript forms and basic SQL."},
        {"C++ Quiz Application", "Software", "A quiz program with questions, scores and result calculation.", {"C++","DSA"}, "Practise arrays, functions and data structures."},
        {"Student Performance Analyzer", "Data", "Prepare simple reports from student marks and records.", {"C++","SQL"}, "Learn SQL queries and basic data analysis."},
        {"AI Student Assistant", "AI", "An introductory project that explores a student help assistant.", {"Python","DSA"}, "Strengthen Python and learn basic machine learning concepts."}
    };

    cout << "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'>";
    cout << "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    cout << "<title>SkillBridge Results</title><link rel='stylesheet' href='/style.css'>";
    cout << "<style>body{padding:35px 0;background:#f2f5f8}.result-wrap{max-width:850px;margin:auto;padding:25px;background:white;border:1px solid #dfe5ec;border-radius:8px}.result-card{padding:17px;margin:14px 0;border:1px solid #dfe5ec;border-radius:6px}.percent{color:#315f9e;font-size:22px;font-weight:bold}.back{display:inline-block;margin-top:18px;padding:11px 16px;background:#315f9e;color:white;text-decoration:none;border-radius:4px}.small{color:#687789;font-size:13px;line-height:1.6}</style>";
    cout << "</head><body><main class='result-wrap'>";
    cout << "<p style='color:#315f9e;font-size:11px;font-weight:bold;letter-spacing:1px'>SKILLBRIDGE / PROJECT RESULTS</p>";
    if (student.empty() || skills.empty()) {
        cout << "<h1>Please complete the form</h1><p class='small'>Enter your name and select at least one skill before finding projects.</p>";
    } else {
        cout << "<h1>Hello, " << student << "!</h1>";
        cout << "<p class='small'>Here are project ideas based on the skills you selected.</p>";
        vector<pair<int, int>> order;
        for (int i = 0; i < (int)projects.size(); ++i) {
            if (interest != "All" && !interest.empty() && projects[i].category != interest) continue;
            int matched = 0;
            for (const string& required : projects[i].skills)
                if (hasSkill(skills, required)) ++matched;
            int percent = (int)(100.0 * matched / projects[i].skills.size() + 0.5);
            order.push_back({percent, i});
        }
        sort(order.rbegin(), order.rend());
        if (order.empty()) cout << "<p>No projects found for this area. Try choosing Any area.</p>";
        for (auto entry : order) {
            const Project& p = projects[entry.second];
            cout << "<article class='result-card'><div style='display:flex;justify-content:space-between;gap:12px'>";
            cout << "<div><p style='color:#315f9e;font-size:10px;font-weight:bold'>" << p.category << "</p><h2>" << p.name << "</h2></div>";
            cout << "<span class='percent'>" << entry.first << "%</span></div>";
            cout << "<p class='small'>" << p.description << "</p><p class='small'><b>Skills required:</b> ";
            for (size_t j=0;j<p.skills.size();++j) cout << (j ? ", " : "") << p.skills[j];
            cout << "</p><p class='small'><b>Suggested next step:</b> " << p.nextStep << "</p></article>";
        }
    }
    cout << "<a class='back' href='/index.html#finder'>Back to project finder</a>";
    cout << "</main></body></html>";
    return 0;
}
